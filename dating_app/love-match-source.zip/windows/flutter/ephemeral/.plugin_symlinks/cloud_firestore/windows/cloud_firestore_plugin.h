/*
 * Copyright 2023, the Chromium project authors.  Please see the AUTHORS file
 * for details. All rights reserved. Use of this source code is governed by a
 * BSD-style license that can be found in the LICENSE file.
 */

#ifndef FLUTTER_PLUGIN_CLOUD_FIRESTORE_PLUGIN_H_
#define FLUTTER_PLUGIN_CLOUD_FIRESTORE_PLUGIN_H_

#include <flutter/event_channel.h>
#include <flutter/method_channel.h>
#include <flutter/plugin_registrar_windows.h>

#include <chrono>
#include <condition_variable>
#include <memory>
#include <mutex>
#include <vector>

#include "firebase/app.h"
#include "firebase/firestore.h"
#include "firebase/log.h"
#include "firebase_core/firebase_core_plugin_c_api.h"
#include "messages.g.h"

namespace cloud_firestore_windows {

enum class TransactionResponseStatus {
  kReceived,
  kTimedOut,
  kCancelled,
};

class TransactionResponse {
 public:
  void Reset();
  void Complete(InternalTransactionResult result,
                std::vector<InternalTransactionCommand> commands);
  TransactionResponseStatus WaitFor(
      std::chrono::milliseconds timeout, InternalTransactionResult& result,
      std::vector<InternalTransactionCommand>& commands);
  void Cancel();

 private:
  std::mutex mutex_;
  std::condition_variable condition_;
  bool response_received_ = false;
  bool cancelled_ = false;
  InternalTransactionResult result_ = InternalTransactionResult::kSuccess;
  std::vector<InternalTransactionCommand> commands_;
};

class CloudFirestorePlugin : public flutter::Plugin,
                             public FirebaseFirestoreHostApi {
 public:
  static void RegisterWithRegistrar(flutter::PluginRegistrarWindows* registrar);
  static firebase::firestore::FieldValue ConvertToFieldValue(
      const flutter::EncodableValue& variant);
  static flutter::EncodableValue ConvertFieldValueToEncodableValue(
      const firebase::firestore::FieldValue& fieldValue);

  CloudFirestorePlugin();

  virtual ~CloudFirestorePlugin();

  static std::string GetErrorCode(firebase::firestore::Error authError);

  static FlutterError ParseError(const firebase::FutureBase& completed_future);

  // Disallow copy and assign.
  CloudFirestorePlugin(const CloudFirestorePlugin&) = delete;
  CloudFirestorePlugin& operator=(const CloudFirestorePlugin&) = delete;

  // FirebaseFirestoreHostApi methods.

  // Inherited via FirebaseFirestoreHostApi
  virtual void LoadBundle(
      const FirestorePigeonFirebaseApp& app, const std::vector<uint8_t>& bundle,
      std::function<void(ErrorOr<std::string> reply)> result) override;
  virtual void NamedQueryGet(
      const FirestorePigeonFirebaseApp& app, const std::string& name,
      const InternalGetOptions& options,
      std::function<void(ErrorOr<InternalQuerySnapshot> reply)> result)
      override;
  virtual void ClearPersistence(
      const FirestorePigeonFirebaseApp& app,
      std::function<void(std::optional<FlutterError> reply)> result) override;
  virtual void DisableNetwork(
      const FirestorePigeonFirebaseApp& app,
      std::function<void(std::optional<FlutterError> reply)> result) override;
  virtual void EnableNetwork(
      const FirestorePigeonFirebaseApp& app,
      std::function<void(std::optional<FlutterError> reply)> result) override;
  virtual void Terminate(
      const FirestorePigeonFirebaseApp& app,
      std::function<void(std::optional<FlutterError> reply)> result) override;
  virtual void WaitForPendingWrites(
      const FirestorePigeonFirebaseApp& app,
      std::function<void(std::optional<FlutterError> reply)> result) override;
  virtual void SetIndexConfiguration(
      const FirestorePigeonFirebaseApp& app,
      const std::string& index_configuration,
      std::function<void(std::optional<FlutterError> reply)> result) override;
  virtual void SetLoggingEnabled(
      bool logging_enabled,
      std::function<void(std::optional<FlutterError> reply)> result) override;
  virtual void SnapshotsInSyncSetup(
      const FirestorePigeonFirebaseApp& app,
      std::function<void(ErrorOr<std::string> reply)> result) override;
  virtual void TransactionCreate(
      const FirestorePigeonFirebaseApp& app, int64_t timeout,
      int64_t max_attempts,
      std::function<void(ErrorOr<std::string> reply)> result) override;
  virtual void TransactionStoreResult(
      const std::string& transaction_id,
      const InternalTransactionResult& result_type,
      const flutter::EncodableList* commands,
      std::function<void(std::optional<FlutterError> reply)> result) override;
  virtual void TransactionGet(
      const FirestorePigeonFirebaseApp& app, const std::string& transaction_id,
      const std::string& path,
      std::function<void(ErrorOr<InternalDocumentSnapshot> reply)> result)
      override;
  virtual void DocumentReferenceSet(
      const FirestorePigeonFirebaseApp& app,
      const DocumentReferenceRequest& request,
      std::function<void(std::optional<FlutterError> reply)> result) override;
  virtual void DocumentReferenceUpdate(
      const FirestorePigeonFirebaseApp& app,
      const DocumentReferenceRequest& request,
      std::function<void(std::optional<FlutterError> reply)> result) override;
  virtual void DocumentReferenceGet(
      const FirestorePigeonFirebaseApp& app,
      const DocumentReferenceRequest& request,
      std::function<void(ErrorOr<InternalDocumentSnapshot> reply)> result)
      override;
  virtual void DocumentReferenceDelete(
      const FirestorePigeonFirebaseApp& app,
      const DocumentReferenceRequest& request,
      std::function<void(std::optional<FlutterError> reply)> result) override;
  virtual void QueryGet(
      const FirestorePigeonFirebaseApp& app, const std::string& path,
      bool is_collection_group, const InternalQueryParameters& parameters,
      const InternalGetOptions& options,
      std::function<void(ErrorOr<InternalQuerySnapshot> reply)> result)
      override;
  virtual void AggregateQuery(
      const FirestorePigeonFirebaseApp& app, const std::string& path,
      const InternalQueryParameters& parameters, const AggregateSource& source,
      const flutter::EncodableList& queries, bool is_collection_group,
      std::function<void(ErrorOr<flutter::EncodableList> reply)> result)
      override;
  virtual void WriteBatchCommit(
      const FirestorePigeonFirebaseApp& app,
      const flutter::EncodableList& writes,
      std::function<void(std::optional<FlutterError> reply)> result) override;
  virtual void QuerySnapshot(
      const FirestorePigeonFirebaseApp& app, const std::string& path,
      bool is_collection_group, const InternalQueryParameters& parameters,
      const InternalGetOptions& options, bool include_metadata_changes,
      const ListenSource& source,
      std::function<void(ErrorOr<std::string> reply)> result) override;
  virtual void DocumentReferenceSnapshot(
      const FirestorePigeonFirebaseApp& app,
      const DocumentReferenceRequest& parameters, bool include_metadata_changes,
      const ListenSource& source,
      std::function<void(ErrorOr<std::string> reply)> result) override;
  virtual void PersistenceCacheIndexManagerRequest(
      const FirestorePigeonFirebaseApp& app,
      const PersistenceCacheIndexManagerRequestEnum& request,
      std::function<void(std::optional<FlutterError> reply)> result) override;
  virtual void ExecutePipeline(
      const FirestorePigeonFirebaseApp& app,
      const ::flutter::EncodableList& stages,
      const ::flutter::EncodableMap* options,
      std::function<void(ErrorOr<InternalPipelineSnapshot> reply)> result)
      override;

  // Per-registration messenger. A Windows app can host several Flutter engines
  // in the same process (e.g. via `desktop_multi_window`), and each one
  // registers the plugin with its own registrar. Keeping this per instance
  // means every channel is built on the messenger of the engine that asked for
  // it, instead of whichever engine registered last.
  flutter::BinaryMessenger* messenger_ = nullptr;
  static std::map<
      std::string,
      std::unique_ptr<flutter::EventChannel<flutter::EncodableValue>>>
      event_channels_;
  static std::map<std::string, std::unique_ptr<flutter::StreamHandler<>>>
      stream_handlers_;
  static std::map<std::string, flutter::StreamHandler<>*> transaction_handlers_;
  static std::map<std::string,
                  std::shared_ptr<firebase::firestore::Transaction>>
      transactions_;
  static std::map<std::string, std::unique_ptr<firebase::firestore::Firestore>>
      firestoreInstances_;
};

firebase::firestore::MapFieldValue ConvertToMapFieldValue(
    const flutter::EncodableMap& originalMap);

std::vector<firebase::firestore::FieldPath> ConvertToFieldPathVector(
    const flutter::EncodableList& encodableList);

}  // namespace cloud_firestore_windows

#endif  // FLUTTER_PLUGIN_CLOUD_FIRESTORE_PLUGIN_H_
